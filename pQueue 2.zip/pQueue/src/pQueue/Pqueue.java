package pQueue;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;

public class Pqueue {

	public static void main(String args[]) {
		Queue<Integer> pq = new PriorityQueue(7);
		System.out.println("hey");
		System.out.println(pq.size());
		Random rand = new Random();
		for(int i = 0; i < pq.size(); i++) {
			pq.add(new Integer(rand.nextInt(100)));
			System.out.println(pq);
		}
		for(int i = 0; i < pq.size(); i++) {
			int integer = pq.poll();
			System.out.println(integer);
		}
	}
    
    //I acknowledge that Ria aided in the construction of this program
    //We both worked together to create the for loops and debug the program
	
}
